# Supply Chain Analyst Portfolio Template (IMAGE INTRO VERSION)

A clean, professional portfolio website template with support for custom Canva intro images. Perfect for supply chain analysts who want a creative, visual introduction. Built with HTML, CSS, and JavaScript - completely free to host on GitHub Pages!

## 🎨 Features

- ✅ **Canva Image Support** - Use your custom intro design
- ✅ Modern, professional design
- ✅ Fully responsive (mobile, tablet, desktop)
- ✅ Ready for projects with clickable links
- ✅ Smooth animations and transitions
- ✅ Easy to customize
- ✅ No frameworks needed - pure HTML/CSS/JS
- ✅ Free hosting on GitHub Pages
- ✅ Custom domain support (optional)

## 📋 Files Included

- `index.html` - Main HTML file (supports image intro!)
- `style.css` - All styling and design
- `script.js` - Interactive animations
- `README.md` - This instruction file
- `CUSTOMIZATION_CHECKLIST.md` - Quick customization guide

## 🚀 Quick Start Guide

### Step 1: Prepare Your Canva Intro Image

1. **Design your intro in Canva** (like the example you showed me!)
2. **Export as PNG**:
   - Click "Share" → "Download"
   - File type: **PNG**
   - Quality: **High** (recommended)
3. **Name your file**: `intro-image.png` (or remember the name)

### Step 2: Create a GitHub Account (if you don't have one)

1. Go to [github.com](https://github.com)
2. Click "Sign up"
3. Choose a username (this will be part of your portfolio URL)
4. Complete the registration

### Step 3: Create a New Repository

1. Click the **"+"** icon in the top right corner
2. Select **"New repository"**
3. Name it: `your-username.github.io` 
   - ⚠️ IMPORTANT: Replace "your-username" with your actual GitHub username
   - Example: If your username is "johndoe", name it `johndoe.github.io`
4. Make it **Public**
5. ✅ Check "Add a README file"
6. Click **"Create repository"**

### Step 4: Upload Your Files

1. In your new repository, click **"Add file"** → **"Upload files"**
2. Drag and drop ALL these files:
   - `index.html`
   - `style.css`
   - `script.js`
   - **`intro-image.png`** ← YOUR CANVA IMAGE (most important!)
3. Scroll down and click **"Commit changes"**

### Step 5: Enable GitHub Pages

1. Go to **Settings** (tab at the top of your repository)
2. Scroll down to **"Pages"** in the left sidebar
3. Under "Source", select **"main"** branch
4. Click **"Save"**
5. Wait 1-2 minutes for your site to build

### Step 6: Visit Your Live Site! 🎉

Your portfolio is now live at: `https://your-username.github.io`

Example: `https://johndoe.github.io`

---

## 🖼️ How the Intro Image Works

### In the HTML file (Line 17-19):

```html
<img src="intro-image.png" alt="Your Name - Supply Chain Analyst Introduction" class="intro-banner">
```

### Important Notes:

1. **File name must match**: If you named your Canva export something else (like `my-intro.png`), change `intro-image.png` to match
2. **File location**: Your image MUST be in the same folder as `index.html`
3. **Supported formats**: PNG (recommended), JPG, JPEG, WebP
4. **Image size**: 
   - Recommended width: 1200-1600px
   - Keeps quality high but loads fast
   - Canva usually exports at good sizes

### If Your Image Doesn't Show:

1. ✅ Check the filename matches exactly (case-sensitive!)
2. ✅ Make sure you uploaded the image to GitHub
3. ✅ Wait 1-2 minutes after uploading
4. ✅ Clear your browser cache (Ctrl + Shift + R)

---

## ✏️ Customization Guide

### 1. Update Your Skills

In `index.html`, find the Skills Section (around line 45) and edit:

```html
<span class="skill-tag">Excel (Advanced)</span>
<span class="skill-tag">Python</span>
```

**To add a skill**: Copy a `<span>` line and change the text  
**To remove a skill**: Delete the entire `<span>` line

### 2. Update Contact Links

Find the Contact Section (around line 145) and update:

```html
<a href="mailto:your.email@example.com" class="contact-link">
<a href="https://linkedin.com/in/yourprofile" target="_blank" class="contact-link">
<a href="https://github.com/yourusername" target="_blank" class="contact-link">
```

Replace with your actual:
- Email address
- LinkedIn profile URL
- GitHub username

### 3. Update Footer

Find line 182:
```html
<p>&copy; 2025 Your Name. All rights reserved.</p>
```
Change "Your Name" to your actual name.

### 4. Change Image File Name

If your Canva image has a different name, go to line 17 and change:

```html
<img src="YOUR-IMAGE-NAME-HERE.png" alt="...">
```

---

## 📁 Adding Projects (When Ready)

### Step 1: Prepare Your Project

You need:
- **Screenshot/image** of your project (save as `project1.png`)
- **Project title**
- **Brief description** (2-3 sentences)
- **Skills used** (Python, Tableau, etc.)
- **Link** to your project (GitHub repo, Tableau Public, Google Drive, etc.)

### Step 2: Upload Project Image

Upload `project1.png` to your GitHub repository (same folder as other files)

### Step 3: Edit HTML

In `index.html`, find the Projects Section (around line 100) and REPLACE the placeholder with:

```html
<div class="project-card">
    <div class="project-image">
        <img src="project1.png" alt="Project Name">
    </div>
    <div class="project-content">
        <h3 class="project-title">Supply Chain Optimization Dashboard</h3>
        <p class="project-description">
            Created an interactive Tableau dashboard analyzing inventory trends 
            across 50+ locations, reducing stock-outs by 25% and saving $200K annually.
        </p>
        <div class="project-tags">
            <span class="skill-tag">Tableau</span>
            <span class="skill-tag">Python</span>
            <span class="skill-tag">SQL</span>
        </div>
        <a href="https://your-project-link.com" target="_blank" class="project-link">
            View Project →
        </a>
    </div>
</div>
```

### Step 4: Add More Projects

To add another project, just copy the entire `<div class="project-card">...</div>` block and paste it below, then update with your new project info!

---

## 🎨 Changing Colors (Optional)

Open `style.css` and edit the color variables at the top (lines 6-10):

```css
:root {
    --primary-color: #1a3a52;        /* Deep blue */
    --accent-color: #e67e22;         /* Orange accent */
    --accent-secondary: #16a085;     /* Teal accent */
}
```

**Color Schemes to Try:**

### Professional Blue (Current)
```css
--primary-color: #1a3a52;
--accent-color: #e67e22;
--accent-secondary: #16a085;
```

### Modern Purple
```css
--primary-color: #6C63FF;
--accent-color: #FF6584;
--accent-secondary: #4ECDC4;
```

### Corporate Teal
```css
--primary-color: #1abc9c;
--accent-color: #3498db;
--accent-secondary: #f39c12;
```

### Bold Red
```css
--primary-color: #e74c3c;
--accent-color: #34495e;
--accent-secondary: #f39c12;
```

Find more colors at [coolors.co](https://coolors.co)

---

## 🔄 How to Update Your Site

After making ANY changes:

1. Go to your GitHub repository
2. Click on the file you want to update
3. Click the **pencil icon** (Edit this file)
4. Make your changes
5. Scroll down and click **"Commit changes"**
6. Wait 1-2 minutes for changes to go live

### To Replace Your Intro Image:

1. Go to your repository
2. Click on `intro-image.png`
3. Click the **trash icon** to delete it
4. Click **"Add file"** → **"Upload files"**
5. Upload your new image
6. Wait 1-2 minutes, refresh your site!

---

## 🌐 Where Project Links Can Point To

Your project links can go to:

- **GitHub repositories**: `github.com/yourname/project-name`
- **Tableau Public**: `public.tableau.com/profile/yourname`
- **Power BI**: Published reports
- **Google Drive**: Shared documents/presentations (make sure link is public)
- **YouTube**: Project walkthrough videos
- **Medium/LinkedIn**: Articles about your projects
- **Live demos**: If you host apps online

**Important**: Make sure any links you share are **public** (not private/restricted)!

---

## 💡 Tips for Success

### For Your Intro Image (Canva):
1. ✅ Use high contrast colors
2. ✅ Keep text large and readable
3. ✅ Export at high quality (PNG recommended)
4. ✅ Test on mobile - make sure text is readable
5. ✅ Keep file size under 2MB for fast loading

### For Your Portfolio Overall:
1. ✅ Start simple - add one project at a time
2. ✅ Use real data and screenshots
3. ✅ Quantify achievements (saved $X, reduced by Y%)
4. ✅ Keep descriptions concise (2-3 sentences per project)
5. ✅ Test all links before sharing
6. ✅ Check mobile view (use phone to view your site)
7. ✅ Update regularly as you complete projects

---

## 📱 Mobile Optimization

Your site automatically adapts to mobile devices! But here are tips for best mobile experience:

1. **Intro Image**: Make sure text in your Canva design is large enough to read on phone
2. **Test it**: Open your portfolio on your phone after publishing
3. **File size**: Keep intro image under 2MB for fast loading on mobile data

---

## 🐛 Troubleshooting

### Problem: My intro image doesn't show

**Solutions:**
- ✅ Check filename matches exactly in HTML (line 17)
- ✅ Make sure image is uploaded to GitHub
- ✅ Wait 2-3 minutes after uploading
- ✅ Clear browser cache (Ctrl + Shift + R)
- ✅ Check image format (PNG, JPG, JPEG work)

### Problem: Site not loading at all

**Solutions:**
- ✅ Wait 5 minutes after initial setup
- ✅ Repository name must be exactly `yourusername.github.io`
- ✅ Repository must be Public
- ✅ GitHub Pages must be enabled in Settings

### Problem: Changes not showing

**Solutions:**
- ✅ Wait 1-2 minutes after committing
- ✅ Clear browser cache (Ctrl + Shift + R)
- ✅ Try in incognito/private window
- ✅ Check you saved the file properly

### Problem: Layout looks broken

**Solutions:**
- ✅ Make sure all 3 files are uploaded (HTML, CSS, JS)
- ✅ Check for typos in file names
- ✅ Verify HTML tags are properly closed
- ✅ Try different browser

### Problem: Project links don't work

**Solutions:**
- ✅ Make sure link starts with `https://` or `http://`
- ✅ Test link by copying and pasting in new tab
- ✅ Check Google Drive/Tableau links are public
- ✅ Verify `target="_blank"` is included for external links

---

## 🎓 Next Steps After Publishing

1. **Share your portfolio**:
   - Add to LinkedIn profile (About section or Featured)
   - Put on your resume
   - Include in email signature
   - Share with your network

2. **Keep it updated**:
   - Add projects as you complete them
   - Update skills as you learn new tools
   - Refresh intro image if needed

3. **Drive traffic**:
   - Share projects on LinkedIn with link to portfolio
   - Mention in job applications
   - Include in networking emails

4. **Optional upgrades**:
   - Add custom domain (yourname.com)
   - Add blog section
   - Add certifications section
   - Add resume download button

---

## 📚 Resources

- [GitHub Pages Documentation](https://docs.github.com/en/pages)
- [HTML Tutorial](https://www.w3schools.com/html/)
- [CSS Tutorial](https://www.w3schools.com/css/)
- [Canva](https://www.canva.com) - Create your intro image
- [Color Picker](https://htmlcolorcodes.com/)
- [Tableau Public](https://public.tableau.com) - Host dashboards
- [Google Fonts](https://fonts.google.com/)

---

## 🌟 Example Project Descriptions

Here are some examples to inspire your project descriptions:

### Inventory Optimization
> "Developed a Python-based forecasting model that analyzes 3 years of historical data to predict demand patterns. Reduced excess inventory by 30% and improved stock availability by 15%."

### Supply Chain Dashboard
> "Built an interactive Tableau dashboard consolidating data from 5 ERP systems, providing real-time visibility into KPIs across 20+ warehouses. Enabled data-driven decisions that reduced lead times by 2 days."

### Process Improvement
> "Led a cross-functional initiative to streamline the order fulfillment process. Used process mapping and data analysis to identify bottlenecks, resulting in 25% faster order processing and $150K annual savings."

---

## 📞 Need Help?

- **GitHub Issues**: Create an issue in your repository
- **Google**: Most questions answered on Stack Overflow
- **YouTube**: Search "GitHub Pages tutorial"
- **Communities**: Reddit's r/webdev or r/learnprogramming

---

## ✅ Before You Publish Checklist

- [ ] Canva intro image created and exported as PNG
- [ ] Image uploaded to GitHub repository
- [ ] Image filename in HTML matches actual filename
- [ ] Skills updated with YOUR actual skills
- [ ] Contact email, LinkedIn, GitHub updated
- [ ] Footer has your name
- [ ] Tested on desktop browser
- [ ] Tested on mobile phone
- [ ] All links work when clicked
- [ ] No placeholder text remains
- [ ] Ready to share!

---

## ⭐ Credits

Template designed for supply chain professionals who want to showcase their work with a creative, visual introduction. Free to use for personal portfolios!

**Good luck with your portfolio!** 🚀

Remember: Start simple, add projects gradually, and keep it updated. Your portfolio will grow with your career!
